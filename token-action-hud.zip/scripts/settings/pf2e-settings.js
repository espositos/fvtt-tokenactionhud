export function registerSettings() {
}