export function registerSettings() {
}
    